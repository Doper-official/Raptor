#version 450

layout(location = 0) in vec2 inNdc;
layout(location = 0) out vec4 outColor;

layout(std140, set = 0, binding = 0) uniform GlobalUbo {
  mat4 projection;
  mat4 view;
  mat4 inverseView;
  mat4 directionalLightViewProjection;
  vec4 ambientLightColor;
  vec4 directionalLightDirection;
}
ubo;

layout(set = 1, binding = 0) uniform samplerCube environmentMap;

layout(push_constant) uniform SkyboxPushConstants {
  mat4 inverseProjection;
  vec4 time;
}
pc;

vec3 calculateSun(vec3 direction) {
  vec3 sunDirection = normalize(-ubo.directionalLightDirection.xyz);

  float sunDot = max(dot(direction, sunDirection), 0.0);

  float sunDisk = smoothstep(cos(radians(0.65)), cos(radians(0.25)), sunDot);

  float softGlow = pow(sunDot, 16.0);
  float wideGlow = pow(sunDot, 5.0);

  vec3 sunColor = vec3(1.0, 0.83, 0.57);

  return sunColor * (sunDisk * 1.8 + softGlow * 0.18 + wideGlow * 0.045);
}

void main() {
  vec4 viewPosition = pc.inverseProjection * vec4(inNdc, 1.0, 1.0);

  vec3 viewDirection = normalize(viewPosition.xyz / viewPosition.w);

  vec3 worldDirection = normalize(mat3(ubo.inverseView) * viewDirection);

  vec3 color = texture(environmentMap, worldDirection).rgb;

  color += calculateSun(worldDirection);

  outColor = vec4(color, 1.0);
}
RAPTOR PORTABLE WINDOWS X64 PACKAGE FIX

Files in this bundle:
- C/launcher.c: console launcher; prefers bundled runtime/bin/java.exe.
- java-Main.java: Main with non-zero exit on failure.
- java-Raptor.java: locates raptor.dll beside the JAR or in native/.
- build-release-package.bat: compiles Java classes, creates a clean JAR, builds the launcher, copies native assets, bundles a Java runtime, and creates a ZIP.
- CMake-snippet.txt: target configuration for a console launcher using wmain.

INSTALL THE SOURCE FILES
1. Replace your project java\Main.java with java-Main.java (rename to Main.java).
2. Replace your project java\Raptor.java with java-Raptor.java (rename to Raptor.java).
3. Replace C\launcher.c with this bundle's C\launcher.c.
4. Merge CMake-snippet.txt into your existing CMakeLists.txt. Do not create a duplicate target if RaptorJarLauncher already exists; update the existing target instead.
5. Ensure the native Release build outputs:
   Release builds\raptor.dll
   Release builds\models\...
   Release builds\shaders\...
6. Ensure the launcher CMake build tree really is out\build\x64-Release. If not, edit CMAKE_BUILD in build-release-package.bat.
7. Open a Developer PowerShell with CMake, and a full JDK 27 available. Set JAVA_HOME to the JDK root if it is not already correct.
8. Run build-release-package.bat from the Engine project root.

Expected portable output:
dist\Raptor-Windows-x64\
  RaptorJarLauncher.exe
  Raptor-Release.jar
  raptor.dll
  runtime\bin\java.exe
  models\...
  shaders\...

The JAR intentionally contains Java classes only. Native DLL and C++ engine assets are external files because the native engine needs filesystem paths for them. The launcher sets the working directory to the package folder so relative model/shader paths work.

PORTABILITY LIMITS
This is a Windows x64 package, not a universal package for every OS/CPU. It bundles Java so the target PC does not need a separate Java installation. It still requires a compatible Vulkan-capable GPU/driver and any third-party DLL dependencies required by raptor.dll. If the native DLL was built for a different architecture, it will not load.

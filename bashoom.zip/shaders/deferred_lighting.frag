#version 450

layout(location = 0) in vec2 fragUV;
layout(location = 0) out vec4 outColor;

struct PointLight {
    vec4 position;
    vec4 color;
};

layout(set = 0, binding = 0) uniform GlobalUbo {
    mat4 projection;
    mat4 view;
    mat4 inverseView;
    vec4 ambientLightColor;
    PointLight pointLights[10];
    int numLights;
} ubo;

layout(set = 1, binding = 0) uniform sampler2D albedoTexture;
layout(set = 1, binding = 1) uniform sampler2D normalTexture;
layout(set = 1, binding = 2) uniform sampler2D depthTexture;

void main() {
    ivec2 pixel = ivec2(gl_FragCoord.xy);
    ivec2 dimensions = textureSize(albedoTexture, 0);

    // Keep pixel coordinates in range in case the viewport and image differ by rounding.
    pixel = clamp(pixel, ivec2(0), dimensions - ivec2(1));

    float depth = texelFetch(depthTexture, pixel, 0).r;
    if (depth >= 0.999999) {
        outColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    vec3 albedo = texelFetch(albedoTexture, pixel, 0).rgb;
    vec3 normal = normalize(texelFetch(normalTexture, pixel, 0).xyz);

    // Reconstruct view-space position from depth, then transform to world space.
    vec2 uv = (vec2(pixel) + vec2(0.5)) / vec2(dimensions);
    vec2 ndcXY = uv * 2.0 - 1.0;
    vec4 viewPosition = inverse(ubo.projection) * vec4(ndcXY, depth, 1.0);
    viewPosition /= viewPosition.w;
    vec3 worldPosition = (ubo.inverseView * viewPosition).xyz;

    vec3 cameraPosition = ubo.inverseView[3].xyz;
    vec3 viewDirection = normalize(cameraPosition - worldPosition);

    vec3 lighting = albedo * ubo.ambientLightColor.rgb * ubo.ambientLightColor.a;

    int lightCount = clamp(ubo.numLights, 0, 10);
    for (int i = 0; i < lightCount; ++i) {
        vec3 toLight = ubo.pointLights[i].position.xyz - worldPosition;
        float distanceSquared = max(dot(toLight, toLight), 0.0001);
        float distanceToLight = sqrt(distanceSquared);
        vec3 lightDirection = toLight / distanceToLight;

        float diffuse = max(dot(normal, lightDirection), 0.0);
        float intensity = ubo.pointLights[i].color.w;
        vec3 lightColor = ubo.pointLights[i].color.rgb;

        // Simple inverse-square falloff, tuned for the tutorial's light intensities.
        float attenuation = 1.0 / (1.0 + 0.09 * distanceToLight + 0.032 * distanceSquared);
        vec3 diffuseLight = albedo * lightColor * diffuse * intensity * attenuation;

        vec3 halfwayDirection = normalize(lightDirection + viewDirection);
        float specular = pow(max(dot(normal, halfwayDirection), 0.0), 32.0);
        vec3 specularLight = lightColor * specular * intensity * attenuation * 0.25;

        lighting += diffuseLight + specularLight;
    }

    outColor = vec4(lighting, 1.0);
}

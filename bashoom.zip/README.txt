RAPTOR DEFERRED LIGHTING BATCH

Files in this package:
- include/systems/deferred_lighting_system.hpp (new)
- src/systems/deferred_lighting_system.cpp (new)
- shaders/deferred_lighting.vert (new)
- shaders/deferred_lighting.frag (new)
- src/first_app.cpp (modified version based on the uploaded ZIP)

Install/copy:
1. Copy the new header into your project's include/systems/ folder.
2. Copy the new C++ source into src/systems/.
3. Copy the two GLSL files into shaders/.
4. Replace src/first_app.cpp with the included modified version.
5. Add src/systems/deferred_lighting_system.cpp to your CMake target if your source list is explicit.
6. Add these shader compile commands to compileShaders.bat (adjust the output folder to match your existing convention):
   F:\Vulkan\Bin\glslc.exe shaders\deferred_lighting.vert -o shaders\deferred_lighting.vert.spv
   F:\Vulkan\Bin\glslc.exe shaders\deferred_lighting.frag -o shaders\deferred_lighting.frag.spv

Important assumptions based on your uploaded source:
- Existing simple_shader.vert and simple_shader.frag are the G-buffer versions discussed in chat.
- G-buffer attachment layouts are SHADER_READ_ONLY_OPTIMAL for albedo/normal and DEPTH_STENCIL_READ_ONLY_OPTIMAL for depth.
- The GlobalUbo shader layout matches rap_frame_info.hpp (matrices, ambient, PointLight[10], int numLights).
- The fullscreen pass outputs black where depth is clear, and otherwise computes ambient + point-light diffuse/specular lighting.

This is a first integration batch, not a claim that it has been compiled against your local project. Build and run with Vulkan validation enabled; share the first compiler/validation error verbatim if one appears.

#version 450

layout(location = 0) in vec2 fragOffset;
layout(location = 0) out vec4 outColor;

struct PointLight {
  vec4 position;
  vec4 color;
};

layout(set = 0, binding = 0) uniform GlobalUbo {
  mat4 projection;
  mat4 view;
  mat4 invView;
  vec4 ambientLightColor;
  PointLight pointLights[10];
  int numLights;
}
ubo;

layout(set = 1, binding = 0) uniform sampler2D sceneDepthSampler;

layout(push_constant) uniform Push {
  vec4 position;
  vec4 color;
  float radius;
}
push;

const float M_PI = 3.1415926538;

void main() {
  float dis = length(fragOffset);

  if (dis >= 1.0) {
    discard;
  }

  // Pixel coordinates -> normalized depth texture coordinates.
  vec2 screenUV = gl_FragCoord.xy / vec2(textureSize(sceneDepthSampler, 0));

  float sceneDepth = texture(sceneDepthSampler, screenUV).r;

  // Vulkan's usual depth convention: near = 0, far = 1.
  if (sceneDepth < 1.0 && gl_FragCoord.z > sceneDepth + 0.0001) {
    discard;
  }

  float cosDis = 0.5 * (cos(dis * M_PI) + 1.0);

  outColor = vec4(push.color.xyz + cosDis, cosDis);
}
$ErrorActionPreference = 'Stop'

cmake -S $PSScriptRoot -B (Join-Path $PSScriptRoot 'out/build') -G Ninja -DCMAKE_BUILD_TYPE=Debug
if ($LASTEXITCODE -ne 0) { throw 'CMake configure failed.' }
cmake --build (Join-Path $PSScriptRoot 'out/build')
if ($LASTEXITCODE -ne 0) { throw 'Native build failed.' }
& (Join-Path $PSScriptRoot 'build-java.ps1')
Write-Host 'Native and Java builds completed. Run .\run-java.ps1 to launch Raptor.'

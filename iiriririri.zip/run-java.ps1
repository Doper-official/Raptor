$ErrorActionPreference = 'Stop'

$classes = Join-Path $PSScriptRoot 'java/out'
if (-not (Test-Path (Join-Path $classes 'raptor/RaptorFirstApp.class'))) {
    & (Join-Path $PSScriptRoot 'build-java.ps1')
}

# The native engine uses project-relative model and shader paths, so keep the project root as cwd.
Set-Location $PSScriptRoot
java --enable-native-access=ALL-UNNAMED -cp $classes raptor.RaptorFirstApp @args
if ($LASTEXITCODE -ne 0) { throw "Raptor exited with code $LASTEXITCODE" }

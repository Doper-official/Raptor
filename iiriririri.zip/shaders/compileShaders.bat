@echo off
setlocal EnableExtensions

REM Compile shader sources into shaders/*.spv, matching the paths used by the engine.
set "SRC=%~dp0"
for %%I in ("%SRC%..") do set "PROJECT_ROOT=%%~fI"

if defined VULKAN_SDK (
    set "GLSLC=%VULKAN_SDK%\Bin\glslc.exe"
) else (
    set "GLSLC=F:\Vulkan\Bin\glslc.exe"
)

if not exist "%GLSLC%" (
    echo ERROR: glslc.exe not found: "%GLSLC%"
    echo Set VULKAN_SDK to your Vulkan SDK directory or edit this script.
    exit /b 1
)

set /a FAIL=0
for %%E in (vert frag) do (
    for %%F in ("%SRC%*.%%E") do (
        if exist "%%~fF" (
            echo Compiling %%~nxF
            "%GLSLC%" "%%~fF" -o "%SRC%%%~nxF.spv"
            if errorlevel 1 set /a FAIL+=1
        )
    )
)

if not "%FAIL%"=="0" (
    echo ERROR: %FAIL% shader compilation(s) failed.
    exit /b 1
)

echo Shader compilation finished.
exit /b 0

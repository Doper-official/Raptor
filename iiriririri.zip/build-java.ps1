$ErrorActionPreference = 'Stop'

$javaSource = Join-Path $PSScriptRoot 'java/src/raptor/RaptorFirstApp.java'
$classes = Join-Path $PSScriptRoot 'java/out'

if (-not (Get-Command javac -ErrorAction SilentlyContinue)) {
    throw 'javac was not found. Install a JDK (Java 27 recommended) and add its bin directory to PATH.'
}

New-Item -ItemType Directory -Force -Path $classes | Out-Null
javac -d $classes $javaSource
if ($LASTEXITCODE -ne 0) { throw 'Java compilation failed.' }
Write-Host "Java classes written to $classes"

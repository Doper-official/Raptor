package raptor;

import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Java-owned entry point for Raptor. The Vulkan implementation remains in raptor.dll.
 * Requires Java 22 or newer with the stable Foreign Function & Memory API; intended for Java 27.
 */
public final class RaptorFirstApp {
    private RaptorFirstApp() {}

    public static void main(String[] args) throws Throwable {
        Path dllPath = chooseDllPath(args);
        System.out.println("Loading Raptor native library: " + dllPath.toAbsolutePath());

        Linker linker = Linker.nativeLinker();
        try (Arena arena = Arena.ofConfined()) {
            SymbolLookup library = SymbolLookup.libraryLookup(dllPath, arena);

            MethodHandle create = linker.downcallHandle(
                findSymbol(library, "raptor_first_app_create"),
                FunctionDescriptor.of(ValueLayout.ADDRESS)
            );
            MethodHandle run = linker.downcallHandle(
                findSymbol(library, "raptor_first_app_run"),
                FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.ADDRESS)
            );
            MethodHandle destroy = linker.downcallHandle(
                findSymbol(library, "raptor_first_app_destroy"),
                FunctionDescriptor.ofVoid(ValueLayout.ADDRESS)
            );
            MethodHandle lastError = linker.downcallHandle(
                findSymbol(library, "raptor_last_error"),
                FunctionDescriptor.of(ValueLayout.ADDRESS)
            );

            MemorySegment app = (MemorySegment) create.invokeExact();
            if (app.address() == 0) {
                throw new IllegalStateException(readLastError(lastError));
            }

            try {
                int result = (int) run.invokeExact(app);
                if (result != 0) {
                    throw new IllegalStateException(readLastError(lastError));
                }
            } finally {
                destroy.invokeExact(app);
            }
        }
    }

    private static MemorySegment findSymbol(SymbolLookup lookup, String name) {
        return lookup.find(name)
            .orElseThrow(() -> new UnsatisfiedLinkError("Missing native export: " + name));
    }

    private static String readLastError(MethodHandle lastError) throws Throwable {
        MemorySegment address = (MemorySegment) lastError.invokeExact();
        if (address.address() == 0) {
            return "Native Raptor call failed without an error message.";
        }
        return address.reinterpret(16_384).getString(0);
    }

    private static Path chooseDllPath(String[] args) {
        if (args.length > 0) {
            Path supplied = Path.of(args[0]).toAbsolutePath().normalize();
            if (!Files.isRegularFile(supplied)) {
                throw new IllegalArgumentException("DLL not found: " + supplied);
            }
            return supplied;
        }

        Path debug = Path.of("test builds", "raptor.dll").toAbsolutePath().normalize();
        Path release = Path.of("Release builds", "raptor.dll").toAbsolutePath().normalize();
        if (Files.isRegularFile(debug)) return debug;
        if (Files.isRegularFile(release)) return release;

        throw new IllegalStateException(
            "raptor.dll was not found. Build the CMake target first, or pass its path as the first argument."
        );
    }
}
